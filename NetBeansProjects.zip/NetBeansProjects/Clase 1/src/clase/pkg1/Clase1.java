/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase.pkg1;

import Vista.FRM_DATOS;
import javax.swing.JOptionPane;

/**
 *
 * @author alumno
 */
public class Clase1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, ":v");
        FRM_DATOS nuevo= new FRM_DATOS(null,true);
        nuevo.setLocationRelativeTo(null);
        nuevo.setVisible(true);
    }
    
}
